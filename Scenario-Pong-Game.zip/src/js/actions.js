function Help(id, context){
    addAction({
        type: "help",
        id: id
    }, context);
}

function Start(id, context){
    addAction({
        type: "start",
        id: id
    }, context);
}

function Stop(id, context){
    addAction({
        type: "stop",
        id: id
    }, context);
}